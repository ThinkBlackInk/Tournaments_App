function _instantUpdateSettings() {
return {
	"baseLineGUID": "09bfc16e341a4d1cb1f9b7c11a5b0165",
	"baseURL": "https://phonegapinstantupdate.s3.amazonaws.com/",
	"displayMessageAfterUpdate": false,
	"message": "",
	"systemMessages": "Verbose",
	"autoUpdate": true,
	"displayFirstTimeLoadMessage": true,
	"firstTimeRunMessage": ""
};
}