function _instantUpdateSettings() {
return {
	"baseLineGUID": "b259087e8f394a67b416ba4c4a124197",
	"baseURL": "https://phonegapinstantupdate.s3.amazonaws.com/",
	"displayMessageAfterUpdate": false,
	"message": "",
	"systemMessages": "Verbose",
	"autoUpdate": true,
	"displayFirstTimeLoadMessage": true,
	"firstTimeRunMessage": ""
};
}