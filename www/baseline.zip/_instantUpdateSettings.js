function _instantUpdateSettings() {
return {
	"baseLineGUID": "ff536ca1e902436688dfa81900bc4c02",
	"baseURL": "https://phonegapinstantupdate.s3.amazonaws.com/",
	"displayMessageAfterUpdate": false,
	"message": "",
	"systemMessages": "Verbose",
	"autoUpdate": true,
	"displayFirstTimeLoadMessage": true,
	"firstTimeRunMessage": ""
};
}